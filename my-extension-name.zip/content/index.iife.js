(function(){"use strict";console.log("content script loaded")})();
